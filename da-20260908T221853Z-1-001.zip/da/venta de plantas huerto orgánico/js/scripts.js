// ==========================================
// CLASSES ES6 (Klas pou jesyon done yo)
// ==========================================
class Servicio {
  constructor(id, nombre, precio, stock, img) {
    this.id = id;
    this.nombre = nombre;
    this.precio = precio;
    this.stock = stock;
    this.img = img;
  }
}

class GestorSesion {
  static guardarSesion(adminState) {
    localStorage.setItem("adminSession", adminState ? "active" : "inactive");
  }

  static obtenerSesion() {
    return localStorage.getItem("adminSession") === "active";
  }

  static cerrarSesion() {
    localStorage.removeItem("adminSession");
  }
}

class GestorReservas {
  static obtenerReservas() {
    return JSON.parse(localStorage.getItem("reservas")) || [];
  }

  static guardarReserva(reserva) {
    const reservas = this.obtenerReservas();
    reservas.push(reserva);
    localStorage.setItem("reservas", JSON.stringify(reservas));
  }
}

document.addEventListener("DOMContentLoaded", () => {
  
  // ==========================================
  // BARRA DE ESTADO DINÁMICA
  // ==========================================
  const topBar = document.getElementById("top-bar");
  if (topBar) {
    const esAdmin = GestorSesion.obtenerSesion();
    const reservas = GestorReservas.obtenerReservas();

    if (esAdmin) {
      topBar.innerHTML = `<span style="color: #22c55e; font-weight: bold;">Bienvenido, Administrador</span>`;
    } else if (reservas.length > 0) {
      topBar.innerHTML = `<span style="color: #f59e0b; font-weight: bold;">⚠️ Tienes ${reservas.length} reserva(s) activa(s) registrada(s).</span>`;
    } else {
      topBar.innerHTML = `<span>Bienvenido a Huerto Orgánico SaaS</span>`;
    }
  }

  // ==========================================
  // CARGA DINÁMICA - PAGINA NOSOTROS
  // ==========================================
  const contenedorNosotros = document.getElementById("contenedor-nosotros");
  if (contenedorNosotros) {
    const equipo = [
      {
        nombre: "JOHNNY CILIN",
        rol: "Desarrollador Lead & Creador",
        foto: "img/johnny.jpg", // Foto pa w la ki nan dosye img/
        descripcion: "Especialista en arquitectura SaaS y desarrollo web modular en tecnologías abiertas."
      },
      {
        nombre: "Camila Silva",
        rol: "Especialista UI/UX",
        foto: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300",
        descripcion: "Diseñadora de interfaces accesibles e interactivas para sistemas agrícolas."
      },
      {
        nombre: "Valentina Morales",
        rol: "Consultora de Operaciones",
        foto: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300",
        descripcion: "Encargada de la gestión de clientes e integración de soluciones tecnológicas."
      }
    ];

    contenedorNosotros.innerHTML = "";
    equipo.forEach(integrante => {
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `
        <img src="${integrante.foto}" alt="${integrante.nombre}">
        <h3>${integrante.nombre}</h3>
        <p><strong>${integrante.rol}</strong></p>
        <p>${integrante.descripcion}</p>
      `;
      contenedorNosotros.appendChild(card);
    });
  }

  // ==========================================
  // CATÁLOGO Y LOCALSTORAGE - SERVICIOS
  // ==========================================
  const contenedorServicios = document.getElementById("contenedor-servicios");
  if (contenedorServicios) {
    const servicios = [
      new Servicio(1, "Sistema de Riego Automatizado", 150000, 5, "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=300"),
      new Servicio(2, "Kit de Monitoreo IoT de Suelo", 85000, 8, "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=300"),
      new Servicio(3, "Software Gestión de Cultivo SaaS", 45000, 12, "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=300")
    ];

    function renderServicios() {
      contenedorServicios.innerHTML = "";
      servicios.forEach(s => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
          <img src="${s.img}" alt="${s.nombre}">
          <h3>${s.nombre}</h3>
          <p>Precio: <strong>$${s.precio.toLocaleString('es-CL')} CLP</strong></p>
          <p>Cupos/Stock: <span id="stock-${s.id}">${s.stock}</span> unidades</p>
          <button class="btn-cta" onclick="reservarServicio(${s.id})">¡Contratar Servicio!</button>
        `;
        contenedorServicios.appendChild(card);
      });
    }

    window.reservarServicio = (id) => {
      const s = servicios.find(item => item.id === id);
      if (s && s.stock > 0) {
        s.stock--;
        const stockEl = document.getElementById(`stock-${id}`);
        if (stockEl) stockEl.innerText = s.stock;

        GestorReservas.guardarReserva({
          id: s.id,
          nombre: s.nombre,
          precio: s.precio,
          fecha: new Date().toLocaleDateString('es-CL')
        });

        alert(`¡Reserva exitosa para ${s.nombre}! Se ha guardado localmente.`);
      } else {
        alert("Lo sentimos, no queda stock disponible de este servicio.");
      }
    };

    renderServicios();
  }

  // ==========================================
  // VALIDACIÓN DOM & LOGIN ADMIN - CONTACTO
  // ==========================================
  const formContacto = document.getElementById("form-contacto");
  const formLogin = document.getElementById("form-login");
  const panelAdmin = document.getElementById("panel-admin");
  const seccionContactoLogin = document.getElementById("seccion-contacto-login");

  if (formContacto) {
    formContacto.addEventListener("submit", (e) => {
      e.preventDefault();
      let valid = true;

      const nombre = document.getElementById("nombre").value.trim();
      const telefono = document.getElementById("telefono").value.trim();
      
      const errNombre = document.getElementById("err-nombre");
      const errTelefono = document.getElementById("err-telefono");

      if (errNombre) errNombre.innerText = "";
      if (errTelefono) errTelefono.innerText = "";

      if (nombre.length < 3) {
        if (errNombre) errNombre.innerText = "El nombre debe tener al menos 3 caracteres.";
        valid = false;
      }

      if (isNaN(telefono) || telefono.length < 8) {
        if (errTelefono) errTelefono.innerText = "Ingrese un teléfono válido (solo números, mínimo 8 dígitos).";
        valid = false;
      }

      if (valid) {
        alert("Mensaje enviado con éxito. Nos pondremos en contacto.");
        formContacto.reset();
      }
    });
  }

  if (formLogin) {
    formLogin.addEventListener("submit", (e) => {
      e.preventDefault();
      const user = document.getElementById("user").value.trim();
      const pass = document.getElementById("pass").value.trim();
      const errLogin = document.getElementById("err-login");

      if (user === "admin" && pass === "1234") {
        GestorSesion.guardarSesion(true);
        if (errLogin) errLogin.innerText = "";
        mostrarPanelAdmin();
      } else {
        if (errLogin) errLogin.innerText = "Credenciales incorrectas (Use admin / 1234).";
      }
    });
  }

  function mostrarPanelAdmin() {
    if (panelAdmin) {
      if (seccionContactoLogin) seccionContactoLogin.style.display = "none";
      panelAdmin.style.display = "block";

      const reservasTable = document.getElementById("tabla-reservas-body");
      const reservas = GestorReservas.obtenerReservas();
      
      if (reservasTable) {
        reservasTable.innerHTML = "";
        if (reservas.length === 0) {
          reservasTable.innerHTML = `<tr><td colspan="3">No hay reservas registradas.</td></tr>`;
        } else {
          reservas.forEach(r => {
            reservasTable.innerHTML += `
              <tr>
                <td>${r.nombre}</td>
                <td>$${r.precio.toLocaleString('es-CL')} CLP</td>
                <td>${r.fecha}</td>
              </tr>
            `;
          });
        }
      }
    }
  }

  function ocultarPanelAdmin() {
    if (panelAdmin) panelAdmin.style.display = "none";
    if (seccionContactoLogin) seccionContactoLogin.style.display = "grid";
  }

  // Evento pou bouton Cerrar Sesión nan panel-admin lan
  const btnLogout = document.getElementById("btn-logout");
  if (btnLogout) {
    btnLogout.addEventListener("click", () => {
      GestorSesion.cerrarSesion();
      ocultarPanelAdmin();
      window.location.reload(); // Rechaje pou mete top-bar a jou
    });
  }

  // Auto-cargar panel si ya está logueado
  if (GestorSesion.obtenerSesion()) {
    mostrarPanelAdmin();
  }

  // ==========================================
  // CALCULADORA FINANCIERA & ADS - FINANZAS
  // ==========================================
  const formFinanzas = document.getElementById("form-finanzas");
  if (formFinanzas) {
    formFinanzas.addEventListener("submit", (e) => {
      e.preventDefault();

      const horas = parseFloat(document.getElementById("horas").value.trim());
      const tarifa = parseFloat(document.getElementById("tarifa").value.trim());
      const cpc = parseFloat(document.getElementById("cpc").value.trim());
      const clics = parseFloat(document.getElementById("clics").value.trim());

      const errFinanzas = document.getElementById("err-finanzas");
      const resultadoDiv = document.getElementById("resultado-finanzas");
      if (errFinanzas) errFinanzas.innerText = "";

      if (isNaN(horas) || isNaN(tarifa) || isNaN(cpc) || isNaN(clics)) {
        if (errFinanzas) errFinanzas.innerText = "Por favor, complete todos los campos numéricos correctamente.";
        return;
      }

      const costoDominio = 10000;
      const costoHosting = 45000;
      const costoManoObra = horas * tarifa;
      const costoAdsMensual = cpc * clics;
      const costoTotal = costoDominio + costoHosting + costoManoObra + costoAdsMensual;

      let alertaAdsHtml = "";
      if (costoAdsMensual > 50000) {
        alertaAdsHtml = `
          <div style="background-color: #fef08a; border: 1px solid #eab308; padding: 10px; border-radius: 6px; margin-top: 10px; color: #854d0e;">
         Presupuesto de marketing alto para fase de lanzamiento.
            <br><a href="finanzas.html" class="btn-cta" style="margin-top: 5px; display:inline-block;">Aprobar Campaña Publicitaria</a>
          </div>
        `;
      }

      if (resultadoDiv) {
        resultadoDiv.innerHTML = `
          <div style="background-color: #f1f5f9; padding: 15px; border-radius: 6px; margin-top: 15px;">
            <h3>Desglose del Presupuesto Comercial:</h3>
            <p>• Dominio NIC Chile: $${costoDominio.toLocaleString('es-CL')} CLP</p>
            <p>• Hosting Anual: $${costoHosting.toLocaleString('es-CL')} CLP</p>
            <p>• Mano de Obra (${horas} hrs): $${costoManoObra.toLocaleString('es-CL')} CLP</p>
            <p>• Campaña Google Ads (Mensual): $${costoAdsMensual.toLocaleString('es-CL')} CLP</p>
            <hr style="margin: 10px 0;">
            <h4>Costo Total del Proyecto: $${costoTotal.toLocaleString('es-CL')} CLP</h4>
            ${alertaAdsHtml}
          </div>
        `;
      }
    });
  }

});